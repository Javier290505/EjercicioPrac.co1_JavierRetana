package com.salonbelleza.salonbelleza.controllers;

import com.salonbelleza.salonbelleza.domain.Servicio;
import com.salonbelleza.salonbelleza.service.CategoriaService;
import com.salonbelleza.salonbelleza.service.ServicioService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/servicios")
public class ServicioController {

    private final ServicioService servicioService;
    private final CategoriaService categoriaService;

    public ServicioController(ServicioService servicioService, CategoriaService categoriaService) {
        this.servicioService = servicioService;
        this.categoriaService = categoriaService;
    }

    @GetMapping
    public String listado(Model model) {
        model.addAttribute("servicios", servicioService.listar());
        return "servicio/listado";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("servicio", new Servicio());
        model.addAttribute("categorias", categoriaService.listar());
        return "servicio/modifica";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Integer id, Model model) {
        Servicio servicio = servicioService.obtenerPorId(id);
        if (servicio.getCategoria() != null) {
            servicio.setCategoriaId(servicio.getCategoria().getId());
        }
        model.addAttribute("servicio", servicio);
        model.addAttribute("categorias", categoriaService.listar());
        return "servicio/modifica";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid Servicio servicio, BindingResult result, Model model, RedirectAttributes ra) {
        if (result.hasErrors()) {
            model.addAttribute("categorias", categoriaService.listar());
            return "servicio/modifica";
        }
        servicioService.guardar(servicio);
        ra.addFlashAttribute("msgOk", "Servicio guardado correctamente");
        return "redirect:/servicios";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Integer id, RedirectAttributes ra) {
        try {
            servicioService.eliminar(id);
            ra.addFlashAttribute("msgOk", "Servicio eliminado");
        } catch (Exception e) {
            ra.addFlashAttribute("msgError", e.getMessage());
        }
        return "redirect:/servicios";
    }
}
