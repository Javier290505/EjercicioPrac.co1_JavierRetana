package com.salonbelleza.salonbelleza.repository;

import com.salonbelleza.salonbelleza.domain.Servicio;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ServicioRepository extends JpaRepository<Servicio, Integer> {
    List<Servicio> findByCategoria_Id(Integer categoriaId);
}
