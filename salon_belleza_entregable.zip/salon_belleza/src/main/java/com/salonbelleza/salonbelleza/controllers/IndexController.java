package com.salonbelleza.salonbelleza.controllers;

import com.salonbelleza.salonbelleza.service.ServicioService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class IndexController {

    private final ServicioService servicioService;

    public IndexController(ServicioService servicioService) {
        this.servicioService = servicioService;
    }

    @GetMapping("/")
    public String index(Model model) {
        // Servicio destacado: el primero que exista (si hay datos de prueba del script, funciona)
        model.addAttribute("servicios", servicioService.listar());
        return "index";
    }
}
