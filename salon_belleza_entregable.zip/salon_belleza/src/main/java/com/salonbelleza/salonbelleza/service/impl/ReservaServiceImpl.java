package com.salonbelleza.salonbelleza.service.impl;

import com.salonbelleza.salonbelleza.domain.Reserva;
import com.salonbelleza.salonbelleza.repository.ServicioRepository;
import com.salonbelleza.salonbelleza.repository.ReservaRepository;
import com.salonbelleza.salonbelleza.service.ReservaService;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ReservaServiceImpl implements ReservaService {

    private final ReservaRepository reservaRepository;
    private final ServicioRepository servicioRepository;

    public ReservaServiceImpl(ReservaRepository reservaRepository, ServicioRepository servicioRepository) {
        this.reservaRepository = reservaRepository;
        this.servicioRepository = servicioRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Reserva> listar() {
        return reservaRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Reserva obtenerPorId(Integer id) {
        return reservaRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("No existe la reserva con id " + id));
    }

    @Override
    @Transactional
    public void guardar(Reserva reserva) {
        if (reserva.getServicioId() != null) {
            reserva.setServicio(
                    servicioRepository.findById(reserva.getServicioId())
                            .orElseThrow(() -> new IllegalArgumentException("Servicio inválido"))
            );
        }
        reservaRepository.save(reserva);
    }

    @Override
    @Transactional
    public void eliminar(Integer id) {
        reservaRepository.deleteById(id);
    }
}
