package com.salonbelleza.salonbelleza.controllers;

import com.salonbelleza.salonbelleza.domain.Categoria;
import com.salonbelleza.salonbelleza.service.CategoriaService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/categorias")
public class CategoriaController {

    private final CategoriaService categoriaService;

    public CategoriaController(CategoriaService categoriaService) {
        this.categoriaService = categoriaService;
    }

    @GetMapping
    public String listado(Model model) {
        model.addAttribute("categorias", categoriaService.listar());
        return "categoria/listado";
    }

    @GetMapping("/nueva")
    public String nueva(Model model) {
        model.addAttribute("categoria", new Categoria());
        return "categoria/modifica";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Integer id, Model model) {
        model.addAttribute("categoria", categoriaService.obtenerPorId(id));
        return "categoria/modifica";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid Categoria categoria, BindingResult result, RedirectAttributes ra) {
        if (result.hasErrors()) {
            return "categoria/modifica";
        }
        categoriaService.guardar(categoria);
        ra.addFlashAttribute("msgOk", "Categoría guardada correctamente");
        return "redirect:/categorias";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Integer id, RedirectAttributes ra) {
        try {
            categoriaService.eliminar(id);
            ra.addFlashAttribute("msgOk", "Categoría eliminada");
        } catch (Exception e) {
            ra.addFlashAttribute("msgError", e.getMessage());
        }
        return "redirect:/categorias";
    }
}
