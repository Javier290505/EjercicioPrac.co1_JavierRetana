# aaiello-tienda
Este será el repositorio para el proyecto del curso de Desarrollo Web y patrones Q1 2026
