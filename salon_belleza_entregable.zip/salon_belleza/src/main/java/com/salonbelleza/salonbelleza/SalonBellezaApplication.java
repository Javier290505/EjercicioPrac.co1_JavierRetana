package com.salonbelleza.salonbelleza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalonBellezaApplication {

    public static void main(String[] args) {
        SpringApplication.run(SalonBellezaApplication.class, args);
    }
}
