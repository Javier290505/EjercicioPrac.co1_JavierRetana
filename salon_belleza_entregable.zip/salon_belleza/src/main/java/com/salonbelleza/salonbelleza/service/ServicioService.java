package com.salonbelleza.salonbelleza.service;

import com.salonbelleza.salonbelleza.domain.Servicio;
import java.util.List;

public interface ServicioService {
    List<Servicio> listar();
    Servicio obtenerPorId(Integer id);
    void guardar(Servicio servicio);
    void eliminar(Integer id);
}
