package com.salonbelleza.salonbelleza.repository;

import com.salonbelleza.salonbelleza.domain.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaRepository extends JpaRepository<Categoria, Integer> {
}
