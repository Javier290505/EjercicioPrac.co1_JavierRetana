package com.salonbelleza.salonbelleza.service.impl;

import com.salonbelleza.salonbelleza.domain.Servicio;
import com.salonbelleza.salonbelleza.repository.CategoriaRepository;
import com.salonbelleza.salonbelleza.repository.ServicioRepository;
import com.salonbelleza.salonbelleza.service.ServicioService;
import java.util.List;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ServicioServiceImpl implements ServicioService {

    private final ServicioRepository servicioRepository;
    private final CategoriaRepository categoriaRepository;

    public ServicioServiceImpl(ServicioRepository servicioRepository, CategoriaRepository categoriaRepository) {
        this.servicioRepository = servicioRepository;
        this.categoriaRepository = categoriaRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Servicio> listar() {
        return servicioRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Servicio obtenerPorId(Integer id) {
        return servicioRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("No existe el servicio con id " + id));
    }

    @Override
    @Transactional
    public void guardar(Servicio servicio) {
        // Garantiza que la categoría sea una referencia válida en JPA (a partir de categoriaId del form)
        if (servicio.getCategoriaId() != null) {
            servicio.setCategoria(
                    categoriaRepository.findById(servicio.getCategoriaId())
                            .orElseThrow(() -> new IllegalArgumentException("Categoría inválida"))
            );
        }
        servicioRepository.save(servicio);
    }

    @Override
    @Transactional
    public void eliminar(Integer id) {
        try {
            servicioRepository.deleteById(id);
        } catch (DataIntegrityViolationException e) {
            throw new IllegalStateException("No se puede eliminar el servicio porque tiene reservas asociadas.", e);
        }
    }
}
