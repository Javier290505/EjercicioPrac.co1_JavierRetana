package com.salonbelleza.salonbelleza.controllers;

import com.salonbelleza.salonbelleza.domain.Reserva;
import com.salonbelleza.salonbelleza.service.ReservaService;
import com.salonbelleza.salonbelleza.service.ServicioService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/reservas")
public class ReservaController {

    private final ReservaService reservaService;
    private final ServicioService servicioService;

    public ReservaController(ReservaService reservaService, ServicioService servicioService) {
        this.reservaService = reservaService;
        this.servicioService = servicioService;
    }

    @GetMapping
    public String listado(Model model) {
        model.addAttribute("reservas", reservaService.listar());
        return "reserva/listado";
    }

    @GetMapping("/nueva")
    public String nueva(Model model) {
        model.addAttribute("reserva", new Reserva());
        model.addAttribute("servicios", servicioService.listar());
        return "reserva/modifica";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Integer id, Model model) {
        Reserva reserva = reservaService.obtenerPorId(id);
        if (reserva.getServicio() != null) {
            reserva.setServicioId(reserva.getServicio().getId());
        }
        model.addAttribute("reserva", reserva);
        model.addAttribute("servicios", servicioService.listar());
        return "reserva/modifica";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid Reserva reserva, BindingResult result, Model model, RedirectAttributes ra) {
        if (result.hasErrors()) {
            model.addAttribute("servicios", servicioService.listar());
            return "reserva/modifica";
        }
        reservaService.guardar(reserva);
        ra.addFlashAttribute("msgOk", "Reserva guardada correctamente");
        return "redirect:/reservas";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Integer id, RedirectAttributes ra) {
        reservaService.eliminar(id);
        ra.addFlashAttribute("msgOk", "Reserva eliminada");
        return "redirect:/reservas";
    }
}
