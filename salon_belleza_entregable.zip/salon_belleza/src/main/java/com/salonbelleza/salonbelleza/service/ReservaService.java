package com.salonbelleza.salonbelleza.service;

import com.salonbelleza.salonbelleza.domain.Reserva;
import java.util.List;

public interface ReservaService {
    List<Reserva> listar();
    Reserva obtenerPorId(Integer id);
    void guardar(Reserva reserva);
    void eliminar(Integer id);
}
