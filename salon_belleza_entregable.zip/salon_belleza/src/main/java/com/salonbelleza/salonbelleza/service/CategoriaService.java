package com.salonbelleza.salonbelleza.service;

import com.salonbelleza.salonbelleza.domain.Categoria;
import java.util.List;

public interface CategoriaService {
    List<Categoria> listar();
    Categoria obtenerPorId(Integer id);
    void guardar(Categoria categoria);
    void eliminar(Integer id);
}
